R Code pulled from https://www.statmethods.net/advgraphs/ggplot2.html


```R
# ggplot2 examples
library(ggplot2) 
```


```R
# create factors with value labels 
mtcars$gear <- factor(mtcars$gear,levels=c(3,4,5),
  	labels=c("3gears","4gears","5gears")) 
mtcars$am <- factor(mtcars$am,levels=c(0,1),
  	labels=c("Automatic","Manual")) 
mtcars$cyl <- factor(mtcars$cyl,levels=c(4,6,8),
   labels=c("4cyl","6cyl","8cyl")) 
```


```R
# Kernel density plots for mpg
# grouped by number of gears (indicated by color)
qplot(mpg, data=mtcars, geom="density", fill=gear, alpha=I(.5), 
   main="Distribution of Gas Milage", xlab="Miles Per Gallon", 
   ylab="Density")
```




![png](output_3_1.png)



```R
# Scatterplot of mpg vs. hp for each combination of gears and cylinders
# in each facet, transmittion type is represented by shape and color
qplot(hp, mpg, data=mtcars, shape=am, color=am, 
   facets=gear~cyl, size=I(3),
   xlab="Horsepower", ylab="Miles per Gallon") 
```




![png](output_4_1.png)



```R
# Separate regressions of mpg on weight for each number of cylinders
qplot(wt, mpg, data=mtcars, geom=c("point", "smooth"), 
   method="lm", formula=y~x, color=cyl, 
   main="Regression of MPG on Weight", 
   xlab="Weight", ylab="Miles per Gallon")
```

    Warning message:
    “Ignoring unknown parameters: method, formula”




![png](output_5_2.png)



```R
# Boxplots of mpg by number of gears 
# observations (points) are overlayed and jittered
qplot(gear, mpg, data=mtcars, geom=c("boxplot", "jitter"), 
   fill=gear, main="Mileage by Gear Number",
   xlab="", ylab="Miles per Gallon")
```




![png](output_6_1.png)



```R
load(url('http://baolinwu.github.io/ASG/Zfg.rda'))
```


```R
aa=hist(z, prob=TRUE, breaks=200)
```


![png](output_8_0.png)



```R
aa
```


    $breaks
      [1] -18.4 -18.2 -18.0 -17.8 -17.6 -17.4 -17.2 -17.0 -16.8 -16.6 -16.4 -16.2
     [13] -16.0 -15.8 -15.6 -15.4 -15.2 -15.0 -14.8 -14.6 -14.4 -14.2 -14.0 -13.8
     [25] -13.6 -13.4 -13.2 -13.0 -12.8 -12.6 -12.4 -12.2 -12.0 -11.8 -11.6 -11.4
     [37] -11.2 -11.0 -10.8 -10.6 -10.4 -10.2 -10.0  -9.8  -9.6  -9.4  -9.2  -9.0
     [49]  -8.8  -8.6  -8.4  -8.2  -8.0  -7.8  -7.6  -7.4  -7.2  -7.0  -6.8  -6.6
     [61]  -6.4  -6.2  -6.0  -5.8  -5.6  -5.4  -5.2  -5.0  -4.8  -4.6  -4.4  -4.2
     [73]  -4.0  -3.8  -3.6  -3.4  -3.2  -3.0  -2.8  -2.6  -2.4  -2.2  -2.0  -1.8
     [85]  -1.6  -1.4  -1.2  -1.0  -0.8  -0.6  -0.4  -0.2   0.0   0.2   0.4   0.6
     [97]   0.8   1.0   1.2   1.4   1.6   1.8   2.0   2.2   2.4   2.6   2.8   3.0
    [109]   3.2   3.4   3.6   3.8   4.0   4.2   4.4   4.6   4.8   5.0   5.2   5.4
    [121]   5.6   5.8   6.0   6.2   6.4   6.6   6.8   7.0   7.2   7.4   7.6   7.8
    [133]   8.0   8.2   8.4   8.6   8.8   9.0   9.2   9.4   9.6   9.8  10.0  10.2
    [145]  10.4  10.6  10.8  11.0  11.2  11.4  11.6  11.8  12.0  12.2  12.4  12.6
    [157]  12.8  13.0  13.2  13.4  13.6  13.8  14.0  14.2  14.4  14.6  14.8  15.0
    [169]  15.2  15.4  15.6  15.8  16.0  16.2  16.4  16.6  16.8  17.0  17.2  17.4
    [181]  17.6  17.8  18.0  18.2
    
    $counts
      [1]      1      1      0      0      2      5      0      1      0      0
     [11]      0      1      0      0      0      2      0      2      0      0
     [21]      1      0      2      3      0      0      3      6      9      8
     [31]      1      0      1      0      0      0      0      0      0      0
     [41]      0      0      0      1      2      0      2      0      0      0
     [51]      4      2      1      3      3     10      7      0      4     11
     [61]     11     12     12     11      5     22     20     30     60     45
     [71]     78    188    203    455    876   1310   2306   3717   6061   9681
     [81]  15982  25153  32083  47723  65200  85154 113894 124298 151513 169486
     [91] 182872 197775 182660 182146 170026 151129 137852 100658  84438  64816
    [101]  47856  35994  21257  15744   9430   6074   4028   2088   1282    837
    [111]    448    229    130     87     51     43     37      8     20     12
    [121]     15      6     10      4     11      4      1      5     13      5
    [131]      3      1      2      3      0      0      0      0      0      3
    [141]      0      0      0      0      0      0      0      0      0      1
    [151]      0      0      3      1      7      7      4      2      0      0
    [161]      2      2      0      0      0      1      0      3      0      0
    [171]      0      0      0      0      0      0      1      0      1      0
    [181]      1      2      2
    
    $density
      [1] 2.035962e-06 2.035962e-06 0.000000e+00 0.000000e+00 4.071925e-06
      [6] 1.017981e-05 0.000000e+00 2.035962e-06 0.000000e+00 0.000000e+00
     [11] 0.000000e+00 2.035962e-06 0.000000e+00 0.000000e+00 0.000000e+00
     [16] 4.071925e-06 0.000000e+00 4.071925e-06 0.000000e+00 0.000000e+00
     [21] 2.035962e-06 0.000000e+00 4.071925e-06 6.107887e-06 0.000000e+00
     [26] 0.000000e+00 6.107887e-06 1.221577e-05 1.832366e-05 1.628770e-05
     [31] 2.035962e-06 0.000000e+00 2.035962e-06 0.000000e+00 0.000000e+00
     [36] 0.000000e+00 0.000000e+00 0.000000e+00 0.000000e+00 0.000000e+00
     [41] 0.000000e+00 0.000000e+00 0.000000e+00 2.035962e-06 4.071925e-06
     [46] 0.000000e+00 4.071925e-06 0.000000e+00 0.000000e+00 0.000000e+00
     [51] 8.143850e-06 4.071925e-06 2.035962e-06 6.107887e-06 6.107887e-06
     [56] 2.035962e-05 1.425174e-05 0.000000e+00 8.143850e-06 2.239559e-05
     [61] 2.239559e-05 2.443155e-05 2.443155e-05 2.239559e-05 1.017981e-05
     [66] 4.479117e-05 4.071925e-05 6.107887e-05 1.221577e-04 9.161831e-05
     [71] 1.588051e-04 3.827609e-04 4.133004e-04 9.263629e-04 1.783503e-03
     [76] 2.667111e-03 4.694929e-03 7.567672e-03 1.233997e-02 1.971015e-02
     [81] 3.253875e-02 5.121056e-02 6.531978e-02 9.716223e-02 1.327448e-01
     [86] 1.733703e-01 2.318839e-01 2.530661e-01 3.084748e-01 3.450671e-01
     [91] 3.723205e-01 4.026625e-01 3.718889e-01 3.708424e-01 3.461665e-01
     [96] 3.076930e-01 2.806615e-01 2.049359e-01 1.719126e-01 1.319629e-01
    [101] 9.743302e-02 7.328243e-02 4.327845e-02 3.205419e-02 1.919913e-02
    [106] 1.236644e-02 8.200857e-03 4.251090e-03 2.610104e-03 1.704101e-03
    [111] 9.121112e-04 4.662354e-04 2.646751e-04 1.771287e-04 1.038341e-04
    [116] 8.754638e-05 7.533061e-05 1.628770e-05 4.071925e-05 2.443155e-05
    [121] 3.053944e-05 1.221577e-05 2.035962e-05 8.143850e-06 2.239559e-05
    [126] 8.143850e-06 2.035962e-06 1.017981e-05 2.646751e-05 1.017981e-05
    [131] 6.107887e-06 2.035962e-06 4.071925e-06 6.107887e-06 0.000000e+00
    [136] 0.000000e+00 0.000000e+00 0.000000e+00 0.000000e+00 6.107887e-06
    [141] 0.000000e+00 0.000000e+00 0.000000e+00 0.000000e+00 0.000000e+00
    [146] 0.000000e+00 0.000000e+00 0.000000e+00 0.000000e+00 2.035962e-06
    [151] 0.000000e+00 0.000000e+00 6.107887e-06 2.035962e-06 1.425174e-05
    [156] 1.425174e-05 8.143850e-06 4.071925e-06 0.000000e+00 0.000000e+00
    [161] 4.071925e-06 4.071925e-06 0.000000e+00 0.000000e+00 0.000000e+00
    [166] 2.035962e-06 0.000000e+00 6.107887e-06 0.000000e+00 0.000000e+00
    [171] 0.000000e+00 0.000000e+00 0.000000e+00 0.000000e+00 0.000000e+00
    [176] 0.000000e+00 2.035962e-06 0.000000e+00 2.035962e-06 0.000000e+00
    [181] 2.035962e-06 4.071925e-06 4.071925e-06
    
    $mids
      [1] -18.3 -18.1 -17.9 -17.7 -17.5 -17.3 -17.1 -16.9 -16.7 -16.5 -16.3 -16.1
     [13] -15.9 -15.7 -15.5 -15.3 -15.1 -14.9 -14.7 -14.5 -14.3 -14.1 -13.9 -13.7
     [25] -13.5 -13.3 -13.1 -12.9 -12.7 -12.5 -12.3 -12.1 -11.9 -11.7 -11.5 -11.3
     [37] -11.1 -10.9 -10.7 -10.5 -10.3 -10.1  -9.9  -9.7  -9.5  -9.3  -9.1  -8.9
     [49]  -8.7  -8.5  -8.3  -8.1  -7.9  -7.7  -7.5  -7.3  -7.1  -6.9  -6.7  -6.5
     [61]  -6.3  -6.1  -5.9  -5.7  -5.5  -5.3  -5.1  -4.9  -4.7  -4.5  -4.3  -4.1
     [73]  -3.9  -3.7  -3.5  -3.3  -3.1  -2.9  -2.7  -2.5  -2.3  -2.1  -1.9  -1.7
     [85]  -1.5  -1.3  -1.1  -0.9  -0.7  -0.5  -0.3  -0.1   0.1   0.3   0.5   0.7
     [97]   0.9   1.1   1.3   1.5   1.7   1.9   2.1   2.3   2.5   2.7   2.9   3.1
    [109]   3.3   3.5   3.7   3.9   4.1   4.3   4.5   4.7   4.9   5.1   5.3   5.5
    [121]   5.7   5.9   6.1   6.3   6.5   6.7   6.9   7.1   7.3   7.5   7.7   7.9
    [133]   8.1   8.3   8.5   8.7   8.9   9.1   9.3   9.5   9.7   9.9  10.1  10.3
    [145]  10.5  10.7  10.9  11.1  11.3  11.5  11.7  11.9  12.1  12.3  12.5  12.7
    [157]  12.9  13.1  13.3  13.5  13.7  13.9  14.1  14.3  14.5  14.7  14.9  15.1
    [169]  15.3  15.5  15.7  15.9  16.1  16.3  16.5  16.7  16.9  17.1  17.3  17.5
    [181]  17.7  17.9  18.1
    
    $xname
    [1] "z"
    
    $equidist
    [1] TRUE
    
    attr(,"class")
    [1] "histogram"



```R
x = aa$mid; y = aa$counts
```


```R
plot(x, y); points(x, mf1$fitted, col=2, pch=2)
```


![png](output_11_0.png)



```R
library(splines)
```


```R
mf1 = glm(y~ns(x,df=10), family='poisson')
```


```R
mf1

```


    
    Call:  glm(formula = y ~ ns(x, df = 10), family = "poisson")
    
    Coefficients:
         (Intercept)   ns(x, df = 10)1   ns(x, df = 10)2   ns(x, df = 10)3  
              0.3370            3.2524           -7.3391            6.8487  
     ns(x, df = 10)4   ns(x, df = 10)5   ns(x, df = 10)6   ns(x, df = 10)7  
             14.1449            7.5604           -7.1179            3.4254  
     ns(x, df = 10)8   ns(x, df = 10)9  ns(x, df = 10)10  
             -1.9952           -2.4633            0.9727  
    
    Degrees of Freedom: 182 Total (i.e. Null);  172 Residual
    Null Deviance:	    10560000 
    Residual Deviance: 4765 	AIC: 5526



```R
mf2 = glm(y~ns(x,df=20), family='poisson')
```


```R
cor(log(1+mf1$fitted), log(1+y))

```


0.973639538843867



```R
cor(log(1+mf2$fitted), log(1+y))

```


0.992879468258365



```R
logLik(mf2) - log(length(y))*21
```


    'log Lik.' -2022.518 (df=21)



```R
logLik(mf1) - log(length(y))*11
```


    'log Lik.' -2809.462 (df=11)



```R
sum(mf2$fitted)
```


2455841.00000002



```R
sum(y)
```


2455841



```R
y
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>1</li><li>1</li><li>0</li><li>0</li><li>2</li><li>5</li><li>0</li><li>1</li><li>0</li><li>0</li><li>0</li><li>1</li><li>0</li><li>0</li><li>0</li><li>2</li><li>0</li><li>2</li><li>0</li><li>0</li><li>1</li><li>0</li><li>2</li><li>3</li><li>0</li><li>0</li><li>3</li><li>6</li><li>9</li><li>8</li><li>1</li><li>0</li><li>1</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>1</li><li>2</li><li>0</li><li>2</li><li>0</li><li>0</li><li>0</li><li>4</li><li>2</li><li>1</li><li>3</li><li>3</li><li>10</li><li>7</li><li>0</li><li>4</li><li>11</li><li>11</li><li>12</li><li>12</li><li>11</li><li>5</li><li>22</li><li>20</li><li>30</li><li>60</li><li>45</li><li>78</li><li>188</li><li>203</li><li>455</li><li>876</li><li>1310</li><li>2306</li><li>3717</li><li>6061</li><li>9681</li><li>15982</li><li>25153</li><li>32083</li><li>47723</li><li>65200</li><li>85154</li><li>113894</li><li>124298</li><li>151513</li><li>169486</li><li>182872</li><li>197775</li><li>182660</li><li>182146</li><li>170026</li><li>151129</li><li>137852</li><li>100658</li><li>84438</li><li>64816</li><li>47856</li><li>35994</li><li>21257</li><li>15744</li><li>9430</li><li>6074</li><li>4028</li><li>2088</li><li>1282</li><li>837</li><li>448</li><li>229</li><li>130</li><li>87</li><li>51</li><li>43</li><li>37</li><li>8</li><li>20</li><li>12</li><li>15</li><li>6</li><li>10</li><li>4</li><li>11</li><li>4</li><li>1</li><li>5</li><li>13</li><li>5</li><li>3</li><li>1</li><li>2</li><li>3</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>3</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>1</li><li>0</li><li>0</li><li>3</li><li>1</li><li>7</li><li>7</li><li>4</li><li>2</li><li>0</li><li>0</li><li>2</li><li>2</li><li>0</li><li>0</li><li>0</li><li>1</li><li>0</li><li>3</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>0</li><li>1</li><li>0</li><li>1</li><li>0</li><li>1</li><li>2</li><li>2</li></ol>




```R
y1 = y[90:91]
```


```R
y1
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>169486</li><li>182872</li></ol>




```R
x1 = x[90:91]
```


```R
x1
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>-0.500000000000002</li><li>-0.300000000000002</li></ol>




```R
d1 = glm(y1~x1, family='poisson')
```


```R
d1
```


    
    Call:  glm(formula = y1 ~ x1, family = "poisson")
    
    Coefficients:
    (Intercept)           x1  
        12.2306       0.3801  
    
    Degrees of Freedom: 1 Total (i.e. Null);  0 Residual
    Null Deviance:	    508.7 
    Residual Deviance: 4.548e-12 	AIC: 31.83



```R
d2 = glm(cbind(y1[1],y1[2])~I(x1[2]-x1[1])-1, family='binomial')
```


```R
d2
```


    
    Call:  glm(formula = cbind(y1[1], y1[2]) ~ I(x1[2] - x1[1]) - 1, family = "binomial")
    
    Coefficients:
    I(x1[2] - x1[1])  
             -0.3801  
    
    Degrees of Freedom: 1 Total (i.e. Null);  0 Residual
    Null Deviance:	    508.7 
    Residual Deviance: 0 	AIC: 15.22



```R
aa = hist(z, breaks=200); x = aa$mid; y = aa$counts
```


![png](output_31_0.png)



```R
aa1 = glm(y~ns(x,df=20), family='poisson')
```


```R
tha = aa1$fitted/sum(aa1$fitted)
```


```R
dz = tha/(x[2]-x[1])
```


```R
plot(x, dz, type='b', log='y')
```


![png](output_35_0.png)



```R
dall = approx(x,dz, xout=z,rule=2)$y
```


```R
plot(z, dall, log='y')
```


![png](output_37_0.png)



```R
q0 = median(abs(z))
```


```R
z0 = z[abs(z)<q0]
```


```R
f0 = function(xpar){pi0=1/(1+exp(-xpar[1])); mu0=xpar[2]; sig=exp(xpar[3]);
                   lik1 = sum(dnorm(z0,mu0,sig,log=TRUE)) + length(z0)*log(pi0)
                   pr0 = pnorm(q0,mu0,sig) - pnorm(-q0,mu0,sig)
                   lik2 = (length(z)-length(z0))*log(1-pi0*pr0)
                   return(-lik1-lik2)
                   }
```


```R
optim(c(0,0,0), f0)
```


<dl>
	<dt>$par</dt>
		<dd><style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>3.3703709174563</li><li>0.00267715629563647</li><li>-0.0126797327742933</li></ol>
</dd>
	<dt>$value</dt>
		<dd>2098458.66166246</dd>
	<dt>$counts</dt>
		<dd><style>
.dl-inline {width: auto; margin:0; padding: 0}
.dl-inline>dt, .dl-inline>dd {float: none; width: auto; display: inline-block}
.dl-inline>dt::after {content: ":\0020"; padding-right: .5ex}
.dl-inline>dt:not(:first-of-type) {padding-left: .5ex}
</style><dl class=dl-inline><dt>function</dt><dd>256</dd><dt>gradient</dt><dd>&lt;NA&gt;</dd></dl>
</dd>
	<dt>$convergence</dt>
		<dd>0</dd>
	<dt>$message</dt>
		<dd>NULL</dd>
</dl>




```R
xpar = .Last.value$par
```


```R
pi0=1/(1+exp(-xpar[1])); mu0=xpar[2]; sig=exp(xpar[3])
```


```R
pi0; mu0;sig

```


0.966765610751702



0.00267715629563647



0.987400316346305



```R
lfdr = dnorm(z,mu0,sig)*pi0/dall
```


```R
plot(z[abs(z)>q0], log(lfdr[abs(z)>q0]))
```


![png](output_46_0.png)



```R
sum(lfdr<0.1)
```


573



```R
range(z[lfdr<0.1])
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>-18.2926829268293</li><li>18.1578947368421</li></ol>




```R
z1 = z[lfdr<0.1]
```


```R
range(z1[z1<0]); range(z1[z1>0])
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>-18.2926829268293</li><li>-4.47368421052632</li></ol>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>4.53125</li><li>18.1578947368421</li></ol>




```R
pi1 = pnorm(-4.47368421052632,mu0,sig)*pi0+pnorm(4.53125,mu0,sig,lower=FALSE)*pi0
```


```R
pi1

```


4.98480931138683e-06



```R
pi1/(573/length(z))
```


0.0213645708273744



```R

```
